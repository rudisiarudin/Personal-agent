#!/bin/bash
# Build lokal APK Agen Pribadi: unduh JDK 17 + Android SDK, lalu assembleDebug.
set -x
TOOLS="$HOME/workspace/tools"
mkdir -p "$TOOLS"
cd "$TOOLS"

# --- JDK 17 (Temurin) ---
if [ ! -x "$TOOLS/jdk-17/bin/java" ]; then
  curl -L -o jdk.tar.gz "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" || exit 11
  mkdir -p jdk-17
  tar -xzf jdk.tar.gz -C jdk-17 --strip-components=1 || exit 12
fi
export JAVA_HOME="$TOOLS/jdk-17"
"$JAVA_HOME/bin/java" -version || exit 13

# --- Android SDK command line tools ---
SDK="$TOOLS/android-sdk"
mkdir -p "$SDK/cmdline-tools"
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl -L -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" || exit 21
  unzip -q -o cmdtools.zip -d "$SDK/cmdline-tools" || exit 22
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest" || exit 23
fi
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"

yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1
"$SDK/cmdline-tools/latest/bin/sdkmanager" "platforms;android-34" "build-tools;34.0.0" || exit 24

# --- Build ---
cd "$HOME/workspace/personal-agent-android" || exit 31
echo "sdk.dir=$SDK" > local.properties
./gradlew assembleDebug --no-daemon -Dorg.gradle.jvmargs=-Xmx1200m --stacktrace || exit 32
ls -la app/build/outputs/apk/debug/
echo "BUILD_OK"
