package id.rudi.agent.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONArray

/** Satu item tampilan di layar chat, diturunkan dari riwayat API. */
data class UiMsg(val kind: Kind, val text: String) {
    enum class Kind { USER, ASSISTANT, NOTE }
}

/** Mengubah riwayat format OpenAI (JSONArray) menjadi item tampilan. */
fun deriveUi(history: JSONArray): List<UiMsg> {
    val out = ArrayList<UiMsg>()
    for (i in 0 until history.length()) {
        val m = history.getJSONObject(i)
        when (m.optString("role")) {
            "user" -> out.add(UiMsg(UiMsg.Kind.USER, m.optString("content")))
            "assistant" -> {
                val calls = m.optJSONArray("tool_calls")
                if (calls != null && calls.length() > 0) {
                    for (j in 0 until calls.length()) {
                        val fn = calls.getJSONObject(j).optJSONObject("function")
                        out.add(UiMsg(UiMsg.Kind.NOTE, "Memanggil tool: ${fn?.optString("name") ?: "?"}"))
                    }
                }
                val content = m.optString("content")
                if (content.isNotBlank()) out.add(UiMsg(UiMsg.Kind.ASSISTANT, content))
            }
            "tool" -> out.add(UiMsg(UiMsg.Kind.NOTE, "Hasil tool: ${m.optString("content").take(300)}"))
        }
    }
    return out
}

@Composable
fun ChatScreen(messages: List<UiMsg>, busy: Boolean, apiKeyMissing: Boolean, onSend: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, busy) {
        val count = messages.size + if (busy) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Column(modifier = Modifier.padding(top = 48.dp, start = 12.dp, end = 12.dp)) {
                        Text("Halo, saya agen pribadi Anda.", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Tulis pesan di bawah untuk mulai. Saya bisa mengingat fakta penting, membuat pengingat, dan melihat info perangkat.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        if (apiKeyMissing) {
                            Text(
                                "Catatan: API key belum diisi. Buka Pengaturan (ikon roda gigi) untuk memasukkan API key dan memilih model.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            }
            items(messages) { msg -> MessageRow(msg) }
            if (busy) {
                item {
                    Text(
                        "Agen sedang berpikir…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 6.dp, top = 2.dp)
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Tulis pesan…") },
                modifier = Modifier.weight(1f),
                maxLines = 4
            )
            IconButton(
                enabled = !busy && input.isNotBlank(),
                onClick = {
                    val text = input.trim()
                    input = ""
                    onSend(text)
                }
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Kirim")
            }
        }
    }
}

@Composable
private fun MessageRow(msg: UiMsg) {
    when (msg.kind) {
        UiMsg.Kind.NOTE -> Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
                msg.text,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        UiMsg.Kind.USER, UiMsg.Kind.ASSISTANT -> {
            val isUser = msg.kind == UiMsg.Kind.USER
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
            ) {
                Text(
                    msg.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .widthIn(max = 300.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 13.dp, vertical = 9.dp)
                )
            }
        }
    }
}
