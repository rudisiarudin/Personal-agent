# Agen Pribadi — Personal AI Agent for Android

Aplikasi Android (Kotlin + Jetpack Compose) berisi agen pribadi sederhana bergaya
Hermes Agent versi mini: mengobrol dengan LLM, mengingat fakta tentang pengguna,
dan menjalankan tools langsung di perangkat.

## Fitur v1

- **Chat agen** dengan model apa pun yang kompatibel format OpenAI Chat Completions:
  Meta Model API (`https://api.meta.ai/v1`, model `muse-spark-1.3`), OpenRouter,
  DeepSeek, atau Ollama lokal. Base URL, API key, dan model diatur di layar Pengaturan.
- **Ingatan jangka panjang** — catatan teks tentang pengguna yang disuntikkan ke
  setiap percakapan; bisa diedit manual di layar Ingatan, dan agen bisa menambahnya
  sendiri lewat tool `remember_fact`.
- **Tools (function calling)** yang dieksekusi lokal di HP:
  - `get_current_time` — tanggal & waktu sekarang (perangkat + Asia/Jakarta)
  - `device_info` — model HP, versi Android, level baterai
  - `set_reminder` — pengingat berupa notifikasi setelah jeda menit tertentu
  - `remember_fact` / `read_memory` — menyimpan & membaca ingatan
- **Riwayat percakapan persisten** — tersimpan di penyimpanan internal aplikasi.
- **System prompt bisa diubah** — kepribadian agen diatur sendiri di Pengaturan.

## Cara Build APK

Build lokal di VM tidak dipakai; gunakan salah satu:

1. **GitHub Actions (disarankan)** — push repo ini ke GitHub, buka tab *Actions*,
   workflow *Build debug APK* jalan otomatis, unduh artifact
   `personal-agent-debug-apk` berisi `app-debug.apk`.
2. **Android Studio** — buka folder project, Run ▶.

Lalu install `app-debug.apk` di HP (izinkan "install dari sumber tidak dikenal"
untuk file manager yang dipakai).

## Pemakaian Pertama

1. Buka aplikasi → ikon roda gigi (**Pengaturan**).
2. Isi **Base URL**, **API Key**, dan **Nama Model** sesuai penyedia LLM pilihan.
   Untuk Ollama di laptop satu jaringan WiFi, Base URL `http://<IP-laptop>:11434/v1`
   dan API key boleh dikosongkan.
3. Kembali ke chat dan mulai mengobrol. Contoh perintah yang memakai tools:
   - "Ingatkan saya 30 menit lagi untuk minum obat."
   - "Ingat ya, saya alergi kacang."
   - "Baterai HP saya tinggal berapa?"

## Catatan & Batasan v1

- Pengingat memakai AlarmManager; untuk ketepatan waktu, izinkan "Alarm & pengingat"
  di pengaturan aplikasi Android bila diminta.
- API key tersimpan lokal di aplikasi (SharedPreferences) — jangan bagikan APK hasil
  build yang sudah terisi key bila key di-hardcode (key TIDAK di-hardcode di repo ini).
- Belum ada: input suara, sinkronisasi cloud (Supabase), akses kalender/kontak,
  dan mode latar 24 jam. Itu kandidat v2.

## Struktur

```
app/src/main/java/id/rudi/agent/
├── MainActivity.kt        — rangka aplikasi + loop agen (LLM <-> tools)
├── data/AgentStore.kt     — pengaturan, ingatan, riwayat (lokal)
├── net/AgentApi.kt        — klien HTTP format OpenAI (OkHttp)
├── tools/AgentTools.kt    — definisi + eksekusi tools
├── tools/ReminderReceiver.kt — notifikasi pengingat
└── ui/                    — ChatScreen, SettingsScreen, MemoryScreen
```
