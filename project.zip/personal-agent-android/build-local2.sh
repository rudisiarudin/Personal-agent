#!/bin/bash
# Build lokal percobaan 2: semua unduhan lewat curl (Java sdkmanager gagal di proxy),
# Gradle diberi konfigurasi proxy secara eksplisit.
set -x
TOOLS="$HOME/workspace/tools"
SDK="$TOOLS/android-sdk"
export JAVA_HOME="$TOOLS/jdk-17"
cd "$TOOLS" || exit 41

# --- Paket SDK via curl ---
[ -f platform.zip ] || curl -L -o platform.zip "https://dl.google.com/android/repository/platform-34-ext7_r03.zip" || exit 42
[ -f buildtools.zip ] || curl -L -o buildtools.zip "https://dl.google.com/android/repository/build-tools_r34-linux.zip" || exit 43
mkdir -p "$SDK/platforms" "$SDK/build-tools"
rm -rf /tmp/plat /tmp/bt; mkdir -p /tmp/plat /tmp/bt
unzip -q -o platform.zip -d /tmp/plat || exit 44
unzip -q -o buildtools.zip -d /tmp/bt || exit 45
P_DIR=$(ls /tmp/plat | head -1)
B_DIR=$(ls /tmp/bt | head -1)
rm -rf "$SDK/platforms/android-34" "$SDK/build-tools/34.0.0"
mv "/tmp/plat/$P_DIR" "$SDK/platforms/android-34" || exit 46
mv "/tmp/bt/$B_DIR" "$SDK/build-tools/34.0.0" || exit 47
mkdir -p "$SDK/licenses"
printf "8933bad161af4178b1185d1a37fbf41ea5269c55\nd56f5187479451eabf01fb78af6dfcb131a6481e\n24333f8a63b6825ea9c5514f83c2829b004d1fee\n" > "$SDK/licenses/android-sdk-license"

# --- Gradle 8.7 via curl ---
if [ ! -x "$TOOLS/gradle-8.7/bin/gradle" ]; then
  curl -L -o gradle.zip "https://services.gradle.org/distributions/gradle-8.7-bin.zip" || exit 51
  unzip -q -o gradle.zip -d "$TOOLS" || exit 52
fi

# --- Konfigurasi proxy untuk Gradle (dari env runtime, khusus mesin ini) ---
mkdir -p "$HOME/.gradle"
PURL="${https_proxy:-$HTTPS_PROXY}"
# Format: http://user:pass@host:port
PP=$(echo "$PURL" | sed -E 's#^[a-z]+://##')
PCRED=$(echo "$PP" | cut -d@ -f1)
PHOSTPORT=$(echo "$PP" | cut -d@ -f2)
PUSER=$(echo "$PCRED" | cut -d: -f1)
PPASS=$(echo "$PCRED" | cut -d: -f2-)
PHOST=$(echo "$PHOSTPORT" | cut -d: -f1)
PPORT=$(echo "$PHOSTPORT" | cut -d: -f2)
cat > "$HOME/.gradle/gradle.properties" <<EOF
systemProp.http.proxyHost=$PHOST
systemProp.http.proxyPort=$PPORT
systemProp.http.proxyUser=$PUSER
systemProp.http.proxyPassword=$PPASS
systemProp.https.proxyHost=$PHOST
systemProp.https.proxyPort=$PPORT
systemProp.https.proxyUser=$PUSER
systemProp.https.proxyPassword=$PPASS
systemProp.http.nonProxyHosts=localhost|127.0.0.1
systemProp.https.nonProxyHosts=localhost|127.0.0.1
org.gradle.jvmargs=-Xmx1100m
EOF

# --- Build ---
cd "$HOME/workspace/personal-agent-android" || exit 61
echo "sdk.dir=$SDK" > local.properties
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
"$TOOLS/gradle-8.7/bin/gradle" assembleDebug --no-daemon -Pkotlin.compiler.execution.strategy=in-process --stacktrace || exit 62
ls -la app/build/outputs/apk/debug/
echo "BUILD_OK"
