package id.rudi.agent

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import id.rudi.agent.data.AgentStore
import id.rudi.agent.net.AgentApi
import id.rudi.agent.tools.AgentTools
import id.rudi.agent.ui.ChatScreen
import id.rudi.agent.ui.MemoryScreen
import id.rudi.agent.ui.SettingsScreen
import id.rudi.agent.ui.UiMsg
import id.rudi.agent.ui.deriveUi
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = AgentStore(this)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF2563EB),
                    surfaceVariant = Color(0xFFE9EEF5),
                    background = Color(0xFFF7F9FC),
                    surface = Color(0xFFFFFFFF)
                )
            ) {
                AgentApp(store)
            }
        }
    }
}

private enum class Screen { CHAT, MEMORY, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AgentApp(store: AgentStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Izin notifikasi (Android 13+) agar pengingat bisa tampil.
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val history = remember { store.loadHistory() }          // sumber kebenaran (format API)
    var uiMessages by remember { mutableStateOf(deriveUi(history)) }
    var busy by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf(Screen.CHAT) }
    var configTick by remember { mutableStateOf(0) }        // berubah setelah Pengaturan disimpan

    fun refresh() {
        uiMessages = deriveUi(history)
        store.saveHistory(history)
    }

    fun runAgent() {
        scope.launch {
            try {
                val api = AgentApi(store.baseUrl, store.apiKey, store.model)
                val tools = AgentTools.definitions()
                for (iteration in 0 until 6) {
                    val request = JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", store.buildSystemPrompt()))
                        for (i in 0 until history.length()) put(history.getJSONObject(i))
                    }
                    val message = api.chat(request, tools)
                    history.put(message)
                    refresh()
                    val calls = message.optJSONArray("tool_calls")
                    if (calls == null || calls.length() == 0) break
                    for (j in 0 until calls.length()) {
                        val call = calls.getJSONObject(j)
                        val fn = call.optJSONObject("function")
                        val name = fn?.optString("name").orEmpty()
                        val args = try {
                            JSONObject(fn?.optString("arguments").orEmpty().ifBlank { "{}" })
                        } catch (e: Exception) { JSONObject() }
                        val result = AgentTools.execute(context, store, name, args)
                        history.put(
                            JSONObject()
                                .put("role", "tool")
                                .put("tool_call_id", call.optString("id"))
                                .put("content", result)
                        )
                        refresh()
                    }
                }
            } catch (e: Exception) {
                history.put(
                    JSONObject().put("role", "assistant")
                        .put("content", "Maaf, terjadi kesalahan: ${e.message}")
                )
                refresh()
            } finally {
                busy = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when (screen) {
                            Screen.CHAT -> "Agen Pribadi"
                            Screen.MEMORY -> "Ingatan Agen"
                            Screen.SETTINGS -> "Pengaturan"
                        }
                    )
                },
                navigationIcon = {
                    if (screen != Screen.CHAT) {
                        IconButton(onClick = { screen = Screen.CHAT }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
                        }
                    }
                },
                actions = {
                    if (screen == Screen.CHAT) {
                        IconButton(onClick = { screen = Screen.MEMORY }) {
                            Icon(Icons.Filled.Psychology, contentDescription = "Ingatan")
                        }
                        IconButton(onClick = {
                            while (history.length() > 0) history.remove(0)
                            store.clearHistory()
                            refresh()
                        }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Hapus riwayat")
                        }
                        IconButton(onClick = { screen = Screen.SETTINGS }) {
                            Icon(Icons.Filled.Settings, contentDescription = "Pengaturan")
                        }
                    }
                }
            )
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(modifier = Modifier.padding(padding)) {
            when (screen) {
                Screen.CHAT -> {
                    // configTick dibaca agar status "API key kosong" segar setelah dari Pengaturan
                    val apiKeyMissing = configTick.let { store.apiKey.isBlank() }
                    ChatScreen(
                        messages = uiMessages,
                        busy = busy,
                        apiKeyMissing = apiKeyMissing,
                        onSend = { text ->
                            history.put(JSONObject().put("role", "user").put("content", text))
                            refresh()
                            busy = true
                            runAgent()
                        }
                    )
                }
                Screen.MEMORY -> MemoryScreen(store)
                Screen.SETTINGS -> SettingsScreen(store, onSaved = { configTick++ })
            }
        }
    }
}
