package id.rudi.agent.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Klien untuk endpoint LLM yang kompatibel dengan format OpenAI Chat Completions
 * (Meta Model API, OpenRouter, DeepSeek, Ollama lokal, dsb.).
 */
class AgentApi(
    private val baseUrl: String,
    private val apiKey: String,
    private val model: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    /**
     * Mengirim satu putaran percakapan. Mengembalikan objek "message" dari respons
     * (bisa berisi content dan/atau tool_calls). Melempar Exception dengan pesan
     * yang bisa ditampilkan ke pengguna bila gagal.
     */
    suspend fun chat(messages: JSONArray, tools: JSONArray): JSONObject = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            if (tools.length() > 0) {
                put("tools", tools)
                put("tool_choice", "auto")
            }
        }
        val request = Request.Builder()
            .url(baseUrl.trimEnd('/') + "/chat/completions")
            .addHeader("Content-Type", "application/json")
            .apply { if (apiKey.isNotBlank()) addHeader("Authorization", "Bearer $apiKey") }
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = try {
                    JSONObject(text).optJSONObject("error")?.optString("message").orEmpty()
                } catch (e: Exception) { "" }
                throw Exception(
                    "Server menjawab HTTP ${response.code}" +
                        if (detail.isNotBlank()) ": $detail" else ". Periksa Base URL, API key, dan nama model di Pengaturan."
                )
            }
            val json = JSONObject(text)
            val choices = json.optJSONArray("choices")
            if (choices == null || choices.length() == 0) {
                throw Exception("Respons server tidak berisi jawaban. Periksa nama model di Pengaturan.")
            }
            choices.getJSONObject(0).getJSONObject("message")
        }
    }
}
