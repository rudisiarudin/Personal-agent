# Personal Agent — aturan ProGuard/R8 tambahan (kosong untuk v1).
