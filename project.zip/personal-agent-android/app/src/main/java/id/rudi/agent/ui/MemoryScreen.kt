package id.rudi.agent.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.rudi.agent.data.AgentStore

@Composable
fun MemoryScreen(store: AgentStore) {
    var text by remember { mutableStateOf(store.memory) }
    var savedNote by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Ingatan Agen", style = MaterialTheme.typography.titleMedium)
        Text(
            "Catatan di sini dibaca agen pada setiap percakapan, jadi ia tetap ingat siapa Anda dan preferensi Anda. " +
                "Agen juga bisa menambah catatan sendiri lewat tool remember_fact saat Anda menyebutkan fakta penting. " +
                "Anda bebas mengedit atau menghapus isinya kapan pun.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
        )
        OutlinedTextField(
            value = text, onValueChange = { text = it; savedNote = false },
            label = { Text("Catatan ingatan") },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Button(
            onClick = { store.memory = text; savedNote = true },
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
        ) { Text("Simpan Ingatan") }
        if (savedNote) {
            Text(
                "Tersimpan.",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
