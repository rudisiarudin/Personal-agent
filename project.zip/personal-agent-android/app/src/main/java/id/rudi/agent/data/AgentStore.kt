package id.rudi.agent.data

import android.content.Context
import org.json.JSONArray
import java.io.File

/**
 * Penyimpanan lokal aplikasi: pengaturan API, catatan ingatan (memory),
 * dan riwayat percakapan. Semua tersimpan di perangkat, tidak dikirim ke mana pun
 * selain ke endpoint LLM yang diatur pengguna.
 */
class AgentStore(context: Context) {

    private val prefs = context.getSharedPreferences("agent_store", Context.MODE_PRIVATE)
    private val historyFile = File(context.filesDir, "history.json")

    // ---------- Pengaturan ----------
    var baseUrl: String
        get() = prefs.getString("base_url", DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(value) = prefs.edit().putString("base_url", value.trim().trimEnd('/')).apply()

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(value) = prefs.edit().putString("api_key", value.trim()).apply()

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = prefs.edit().putString("model", value.trim()).apply()

    var systemPrompt: String
        get() = prefs.getString("system_prompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
        set(value) = prefs.edit().putString("system_prompt", value).apply()

    // ---------- Ingatan (memory) ----------
    /** Teks bebas berisi fakta tentang pengguna; disuntikkan ke setiap percakapan. */
    var memory: String
        get() = prefs.getString("memory", "") ?: ""
        set(value) = prefs.edit().putString("memory", value).apply()

    fun appendMemory(fact: String) {
        val current = memory.trim()
        memory = if (current.isEmpty()) "- $fact" else "$current\n- $fact"
    }

    // ---------- Riwayat percakapan ----------
    fun loadHistory(): JSONArray {
        return try {
            if (historyFile.exists()) JSONArray(historyFile.readText()) else JSONArray()
        } catch (e: Exception) {
            JSONArray()
        }
    }

    fun saveHistory(history: JSONArray) {
        try {
            historyFile.writeText(history.toString())
        } catch (e: Exception) {
            // Penyimpanan penuh dsb. — riwayat sesi ini tetap jalan dari RAM.
        }
    }

    fun clearHistory() {
        saveHistory(JSONArray())
    }

    /** System prompt final = prompt dasar + ingatan tentang pengguna. */
    fun buildSystemPrompt(): String {
        val base = systemPrompt.trim()
        val mem = memory.trim()
        return if (mem.isEmpty()) base else "$base\n\nCatatan ingatan tentang pengguna (dari percakapan sebelumnya):\n$mem"
    }

    companion object {
        const val DEFAULT_BASE_URL = "https://api.meta.ai/v1"
        const val DEFAULT_MODEL = "muse-spark-1.3"
        const val DEFAULT_SYSTEM_PROMPT =
            "Kamu adalah agen pribadi yang berjalan di HP Android pengguna. " +
            "Jawablah dalam Bahasa Indonesia yang ramah dan ringkas, kecuali pengguna memakai bahasa lain. " +
            "Kamu punya tools: melihat waktu sekarang (get_current_time), info perangkat (device_info), " +
            "membuat pengingat/notifikasi (set_reminder), dan menyimpan fakta penting tentang pengguna ke ingatan jangka panjang (remember_fact). " +
            "Gunakan remember_fact hanya untuk fakta yang berguna di masa depan (nama, preferensi, kebiasaan, hal penting), bukan untuk hal sepele atau rahasia seperti kata sandi. " +
            "Jika pengguna menyebutkan fakta penting tentang dirinya, simpanlah dengan remember_fact sambil tetap menjawab pertanyaannya."
    }
}
