package id.rudi.agent.tools

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import id.rudi.agent.data.AgentStore
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Tools yang bisa dipanggil model (function calling). Definisi mengikuti
 * format OpenAI tools; eksekusinya lokal di perangkat.
 */
object AgentTools {

    fun definitions(): JSONArray = JSONArray().apply {
        put(tool("get_current_time",
            "Melihat tanggal dan waktu saat ini (zona waktu perangkat dan Asia/Jakarta).",
            JSONObject()))
        put(tool("device_info",
            "Melihat info perangkat pengguna: model HP, versi Android, dan level baterai.",
            JSONObject()))
        put(tool("set_reminder",
            "Membuat pengingat yang muncul sebagai notifikasi setelah jeda waktu tertentu.",
            JSONObject().apply {
                put("title", prop("string", "Isi/judul pengingat, mis. 'Minum obat'"))
                put("delay_minutes", prop("integer", "Jeda dari sekarang dalam menit, mis. 30"))
            }, required = listOf("title", "delay_minutes")))
        put(tool("remember_fact",
            "Menyimpan satu fakta penting tentang pengguna ke ingatan jangka panjang agar diingat di percakapan berikutnya.",
            JSONObject().apply {
                put("fact", prop("string", "Fakta singkat, mis. 'Nama pengguna: Rudi, dipanggil Ketua'"))
            }, required = listOf("fact")))
        put(tool("read_memory",
            "Membaca seluruh catatan ingatan tentang pengguna yang tersimpan.",
            JSONObject()))
    }

    private fun tool(name: String, description: String, props: JSONObject, required: List<String> = emptyList()): JSONObject {
        val params = JSONObject().apply {
            put("type", "object")
            put("properties", props)
            if (required.isNotEmpty()) put("required", JSONArray(required))
        }
        return JSONObject().apply {
            put("type", "function")
            put("function", JSONObject().apply {
                put("name", name)
                put("description", description)
                put("parameters", params)
            })
        }
    }

    private fun prop(type: String, description: String): JSONObject = JSONObject().apply {
        put("type", type)
        put("description", description)
    }

    /** Menjalankan tool dan mengembalikan hasilnya sebagai teks untuk model. */
    fun execute(context: Context, store: AgentStore, name: String, args: JSONObject): String {
        return try {
            when (name) {
                "get_current_time" -> currentTime()
                "device_info" -> deviceInfo(context)
                "set_reminder" -> setReminder(
                    context,
                    args.optString("title", "Pengingat"),
                    args.optInt("delay_minutes", 0)
                )
                "remember_fact" -> {
                    val fact = args.optString("fact").trim()
                    if (fact.isEmpty()) "Gagal: fakta kosong."
                    else { store.appendMemory(fact); "Fakta tersimpan ke ingatan: $fact" }
                }
                "read_memory" -> store.memory.ifBlank { "(ingatan masih kosong)" }
                else -> "Tool tidak dikenal: $name"
            }
        } catch (e: Exception) {
            "Tool $name gagal: ${e.message}"
        }
    }

    private fun currentTime(): String {
        val locale = Locale("id", "ID")
        val fmt = SimpleDateFormat("EEEE, d MMMM yyyy 'pukul' HH:mm:ss z", locale)
        val local = fmt.format(Date())
        fmt.timeZone = TimeZone.getTimeZone("Asia/Jakarta")
        val jakarta = fmt.format(Date())
        return "Waktu perangkat: $local\nWaktu Asia/Jakarta: $jakarta"
    }

    private fun deviceInfo(context: Context): String {
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n" +
            "Baterai: $level%"
    }

    private fun setReminder(context: Context, title: String, delayMinutes: Int): String {
        if (delayMinutes <= 0) return "Gagal: jeda pengingat harus lebih dari 0 menit."
        val triggerAt = System.currentTimeMillis() + delayMinutes * 60_000L
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_TITLE, title)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            (triggerAt % Int.MAX_VALUE).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exactAllowed = Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()
        if (exactAllowed) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        }
        val fmt = SimpleDateFormat("EEEE, d MMMM yyyy 'pukul' HH:mm", Locale("id", "ID"))
        return "Pengingat \"$title\" terpasang untuk ${fmt.format(Date(triggerAt))}" +
            if (exactAllowed) "." else " (mode tidak eksak — izin alarm eksak belum diberikan di Pengaturan Android)."
    }
}
