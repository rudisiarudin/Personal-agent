package id.rudi.agent.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import id.rudi.agent.data.AgentStore

@Composable
fun SettingsScreen(store: AgentStore, onSaved: () -> Unit) {
    var baseUrl by remember { mutableStateOf(store.baseUrl) }
    var apiKey by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var prompt by remember { mutableStateOf(store.systemPrompt) }
    var savedNote by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Koneksi Model (LLM)", style = MaterialTheme.typography.titleMedium)
        Text(
            "Aplikasi ini memakai format OpenAI Chat Completions. Contoh endpoint:\n" +
                "• Meta Model API — https://api.meta.ai/v1 (model: muse-spark-1.3)\n" +
                "• OpenRouter — https://openrouter.ai/api/v1\n" +
                "• DeepSeek — https://api.deepseek.com\n" +
                "• Ollama di laptop satu WiFi — http://<IP-laptop>:11434/v1 (API key boleh kosong)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp, bottom = 14.dp)
        )

        OutlinedTextField(
            value = baseUrl, onValueChange = { baseUrl = it },
            label = { Text("Base URL") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = apiKey, onValueChange = { apiKey = it },
            label = { Text("API Key") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
        )
        OutlinedTextField(
            value = model, onValueChange = { model = it },
            label = { Text("Nama Model") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
        )

        Text(
            "Kepribadian Agen (System Prompt)",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 22.dp)
        )
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it },
            label = { Text("System Prompt") },
            minLines = 4,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )

        Button(
            onClick = {
                store.baseUrl = baseUrl
                store.apiKey = apiKey
                store.model = model
                store.systemPrompt = prompt
                savedNote = true
                onSaved()
            },
            modifier = Modifier.fillMaxWidth().padding(top = 20.dp)
        ) { Text("Simpan Pengaturan") }

        if (savedNote) {
            Text(
                "Tersimpan.",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
